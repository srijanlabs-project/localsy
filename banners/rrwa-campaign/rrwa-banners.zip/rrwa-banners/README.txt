Localisy x RRWA - "Discover Local. Support Local. Grow Local."
==============================================================
Co-branded campaign set. Sizes match the render CSS in
LocalityLandingUiV1.tsx / WebPortal.tsx. Upload the @2x where the slot crops.

DESKTOP (>= 1024px)
  rrwa_desktop_hero-primary_1000x360      homepage_hero_primary       crops
  rrwa_desktop_hero-secondary_263x360     homepage_hero_secondary     crops, PORTRAIT
  rrwa_desktop_hero-junior_256x400        homepage_hero_junior        crops, PORTRAIT
  rrwa_desktop_category-strip_1000x200    homepage_strip_between_...  no crop

MOBILE (< 1024px, sized for a 390px viewport)
  rrwa_mobile_hero_390x360                locality mobile hero        crops
  rrwa_mobile_inline_358x120              mobile_inline               crops
  rrwa_mobile_promo_358x180               homepage_inline_primary     no crop
  rrwa_mobile_category-strip_358x140      homepage_strip_between_...  no crop

ASSETS - all lifted from the supplied artwork, not redrawn
  localisy wordmark   background knocked out to transparent
  RRWA emblem         cut from its background by silhouette (the original crop
                      had city buildings in the emblem's diagonal gap)
  phone mockup        used on the 1000x360 only; too tall for the other slots
  storefront row      bottom band, faded from ~20% height so text never sits on it

PALETTE - sampled from the artwork
  localisy green  #6F8963   headline, CTA (#5E7A53 for contrast on cream)
  localisy orange #E08633   "Grow Local." (#DB7F27 for contrast)
  cream ground    #FEFDF8
  sky             #C0E3FC

COPY NOTE
  The supplied body text ended mid-sentence at "...to help local businesses".
  It is completed here as "...to help local businesses grow." Change it in the
  generator if the intended ending differs.

TO REGENERATE
  banners.html is a single self-contained file (assets inlined as base64).
  Edit the copy, then screenshot each #id at deviceScaleFactor 1 and 2.
