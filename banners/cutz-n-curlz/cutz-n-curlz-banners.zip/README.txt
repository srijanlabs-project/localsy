Cutz N Curlz (Unisex Salon) & Academy — banner set
==================================================
Sizes derived from the render CSS in LocalityLandingUiV1.tsx and WebPortal.tsx.
@2x files are for retina; upload the @2x where the slot crops with object-cover.

DESKTOP (>= 1024px)
  desktop_hero-primary_1000x360      homepage_hero_primary            crops (object-cover)
  desktop_hero-secondary_263x360     homepage_hero_secondary          crops - PORTRAIT
  desktop_hero-junior_256x400        homepage_hero_junior             crops - PORTRAIT
  desktop_category-strip_1000x200    homepage_strip_between_...        no crop (h-auto)

MOBILE (< 1024px, sized for a 390px viewport)
  mobile_hero_390x360                locality mobile hero              crops
  mobile_inline_358x120              mobile_inline / listing_results   crops
  mobile_promo_358x180               homepage_inline_primary           no crop (h-auto)
  mobile_category-strip_358x140      homepage_strip_between_...        no crop (h-auto)

NOT INCLUDED
  listing_results on desktop renders the image at opacity-25 behind overlaid
  text. It is a texture, not a creative slot - anything legible will be lost.

CONTENT USED
  Name       Cutz N Curlz (Unisex Salon) & Academy
  Tier       VIP Core
  Category   Beauty & Wellness / Beauty Parlours
  Services   Haircut, Facial, Hair Styling, Makeup
  Location   Bhoomi Gardenia, Sector 17, Kalamboli / Amrante 410218

  Deliberately omitted: the raw Google tag string ("beauty_salon, hair_salon,
  hair_care, point_of_interest, service, establishment") and the hashtag run.
  Those are import debris, not copy - see claude/content-quality.md.
